#ifndef CLASSROSTER_SECURITYSTUDENT_H
#define CLASSROSTER_SECURITYSTUDENT_H

#include "student.h"

class SecurityStudent : public Student {
private:
	Degree degree = SECURITY;

public:
	SecurityStudent(std::string studentID, std::string firstName, std::string lastName, std::string email,
		int age, int daysInCourse1, int daysInCourse2, int daysInCourse3);

	~SecurityStudent();

	void print() override;

	Degree getDegreeProgram() override;
};

#endif //CLASSROSTER_SECURITYSTUDENT_H