#include "stdafx.h"
#include <iostream>
#include "Roster.h"
#include <vector>


Roster::Roster() {
}

Roster::~Roster() {
	std::cout << "Roster destructed" << std::endl;
}

void Roster::add(std::string studentID, std::string firstName, std::string lastName, std::string email,
	int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, Degree degree) {
	switch (degree) {
	case SECURITY: {
		this->classRosterArray[this->rosterCount] = new SecurityStudent(studentID, firstName, lastName, email, age,
			daysInCourse1,
			daysInCourse2, daysInCourse3);
		this->rosterCount++;
		break;
	}
	case NETWORKING: {
		this->classRosterArray[this->rosterCount] = new NetworkStudent(studentID, firstName, lastName, email, age,
			daysInCourse1,
			daysInCourse2, daysInCourse3);
		this->rosterCount++;
		break;
	}
	case SOFTWARE: {
		this->classRosterArray[this->rosterCount] = new SoftwareStudent(studentID, firstName, lastName, email, age,
			daysInCourse1,
			daysInCourse2, daysInCourse3);
		this->rosterCount++;
		break;
	}
	}
}

void Roster::remove(std::string studentID) {
	for (auto &i : this->classRosterArray) {
		if (i != nullptr) {
			if (i->getStudentID() == studentID) {
				i = nullptr;
				return;
			}
		}
	}

	std::cout << "Student not found" << std::endl;
}

void Roster::printAll() {
	for (auto student : this->classRosterArray) {
		if (student != nullptr) {
			student->print();
		}
	}
}

void Roster::printDaysInCourse(std::string studentID) {
	for (auto student : this->classRosterArray) {
		if (student != nullptr) {
			if (student->getStudentID() == studentID) {
				int sum = 0;
				for (int j = 0; j < 3; j++) {
					sum += student->getDaysInCourse()[j];
				}
				std::cout << studentID << "'s average days in course: " << (sum / 3) << std::endl;
				return;
			}
		}
	}

	std::cout << "Student not found" << std::endl;
}

void Roster::printInvalidEmails() {
	for (auto student : this->classRosterArray) {
		if (student != nullptr) {
			if (!isValidEmail(student->getEmail())) {
				std::cout << student->getEmail() << std::endl;
			}
		}
	}
}

void Roster::printByDegreeProgram(int degreeProgram) {
	for (auto student : this->classRosterArray) {
		if (student != nullptr) {
			if (student->getDegreeProgram() == degreeProgram) {
				student->print();
			}
		}
	}
}
void Roster::displayMyInfos() {
	std::cout << "Course Title: " << "C++ Programming" << std::endl;
	std::cout << "Programming Language Used: " << "C++" << std::endl;
	std::cout << "My Student ID: " << "000639676" << std::endl;
	std::cout << "My Name: " << "Suraj Khatiwoda" << std::endl;
}
bool Roster::isValidEmail(std::string email) {
	const std::regex pattern(R"((\w+)(\.|_)?(\w*)@(\w+)(\.(\w+))+)");
	return std::regex_match(email, pattern);
}

std::vector<std::string> Roster::splitString(std::string string, std::string delimiter) {
	auto start = 0L;
	auto end = string.find(delimiter);
	int splitCount = 0;

	while (end != std::string::npos) {
		start = end + delimiter.length();
		end = string.find(delimiter, start);
		splitCount++;
	}

	std::vector<std::string> stringArray(splitCount + 1);
	start = 0L;
	end = string.find(delimiter);
	splitCount = 0;
	while (end != std::string::npos) {
		stringArray[splitCount] = string.substr(start, end - start);
		start = end + delimiter.length();
		end = string.find(delimiter, start);
		splitCount++;
	}
	stringArray[splitCount] = string.substr(start, end - start);

	return stringArray;
}

Degree Roster::stringToDegree(std::string degreeString) {
	if (degreeString == "NETWORKING")
		return NETWORKING;
	else if (degreeString == "SECURITY")
		return SECURITY;
	else
		return SOFTWARE;
}

int main() {



	std::string studentData[] =
	{ "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY" ,
		"A5, Suraj, Khatiwoda, hnkhatiwoda@gmail.com, 24, 25, 26, 27, SOFTWARE"
	};

	Roster classRoster = Roster();

	for (const auto &i : studentData) {
		std::vector<std::string> splitStudent = Roster::splitString(i, ",");
		classRoster.add(
			splitStudent[0], splitStudent[1], splitStudent[2],
			splitStudent[3], std::stoi(splitStudent[4]), std::stoi(splitStudent[5]),
			std::stoi(splitStudent[6]), std::stoi(splitStudent[7]), Roster::stringToDegree(splitStudent[8])
		);
	}
	classRoster.displayMyInfos();
	std::cout << std::endl;
	std::cout << std::endl;

	classRoster.printAll();

	std::cout << std::endl;

	classRoster.printInvalidEmails();

	std::cout << std::endl;

	for (auto &i : classRoster.classRosterArray) {
		classRoster.printDaysInCourse(i->getStudentID());
	}

	std::cout << std::endl;

	classRoster.printByDegreeProgram(SOFTWARE);

	std::cout << std::endl;

	classRoster.remove("A3");
	classRoster.remove("A3");

	std::cout << std::endl;

	classRoster.printAll();

	std::cout << std::endl;

	classRoster.~Roster();

	//Pause the program
	std::cout << "\n\n---------------------------------\n";
	system("pause");

	//Exit the program
	return EXIT_SUCCESS;

}