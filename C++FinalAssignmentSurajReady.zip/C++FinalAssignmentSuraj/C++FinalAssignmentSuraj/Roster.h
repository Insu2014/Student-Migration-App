#pragma once
#ifndef CLASSROSTER_ROSTER_H
#define CLASSROSTER_ROSTER_H

#include <regex>
#include "netstudents.h"
#include "secstudent.h"
#include "softstudent.h"

class Roster {
private:
	int rosterCount = 0;
	static const int ROSTER_SIZE = 5;

public:
	Student * classRosterArray[ROSTER_SIZE];

	Roster();

	~Roster();

	void
		add(std::string studentID, std::string firstName, std::string lastName, std::string email,
			int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, Degree degree);

	void remove(std::string studentID);

	void printAll();

	void printDaysInCourse(std::string studentID);

	void printInvalidEmails();

	void printByDegreeProgram(int degreeProgram);

	static bool isValidEmail(std::string email);

	static std::vector<std::string> splitString(std::string string, std::string delimiter);

	static Degree stringToDegree(std::string degreeString);
	void displayMyInfos();
};


#endif //CLASSROSTER_ROSTER_H