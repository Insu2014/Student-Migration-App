#pragma once
#ifndef CLASSROSTER_SOFTWARESTUDENT_H
#define CLASSROSTER_SOFTWARESTUDENT_H

#include "student.h"

class SoftwareStudent : public Student {
private:
	Degree degree = SOFTWARE;

public:
	SoftwareStudent(std::string studentID, std::string firstName, std::string lastName, std::string email,
		int age, int daysInCourse1, int daysInCourse2, int daysInCourse3);

	~SoftwareStudent();

	void print() override;

	Degree getDegreeProgram() override;
};

#endif //CLASSROSTER_SOFTWARESTUDENT_H
