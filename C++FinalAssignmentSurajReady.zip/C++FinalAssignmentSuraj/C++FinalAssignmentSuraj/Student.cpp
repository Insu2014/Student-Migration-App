#include "stdafx.h"
#include "Student.h"

Student::Student(std::string studentID, std::string firstName, std::string lastName, std::string email, int age,
	int daysInCourse1, int daysInCourse2, int daysInCourse3) {
	this->studentID = studentID;
	this->firstName = firstName;
	this->lastName = lastName;
	this->email = email;
	this->age = age;
	this->daysInCourse[0] = daysInCourse1;
	this->daysInCourse[1] = daysInCourse2;
	this->daysInCourse[2] = daysInCourse3;
}

Student::~Student() {
	std::cout << "Student destructed" << std::endl;
}

std::string Student::getStudentID() {
	return this->studentID;
}

void Student::setStudentID(std::string studentID) {
	this->studentID = studentID;
}

std::string Student::getFirstName() {
	return this->firstName;
}

void Student::setFirstName(std::string firstName) {
	this->firstName = firstName;
}

std::string Student::getLastName() {
	return this->lastName;
}

void Student::setLastName(std::string lastName) {
	this->lastName = lastName;
}

std::string Student::getEmail() {
	return this->email;
}

void Student::setEmail(std::string email) {
	this->email = email;
}

int Student::getAge() {
	return this->age;
}

void Student::setAge(int age) {
	this->age = age;
}

int *Student::getDaysInCourse() {
	return this->daysInCourse;
}

void Student::setDaysInCourse(int daysInCourse1, int daysInCourse2, int daysInCourse3) {
	this->daysInCourse[0] = daysInCourse1;
	this->daysInCourse[1] = daysInCourse2;
	this->daysInCourse[2] = daysInCourse3;
}