#ifndef CLASSROSTER_NETWORKSTUDENT_H
#define CLASSROSTER_NETWORKSTUDENT_H

#include "student.h"

class NetworkStudent : public Student {
private:
	Degree degree = NETWORKING;

public:
	NetworkStudent(std::string studentID, std::string firstName, std::string lastName, std::string email,
		int age, int daysInCourse1, int daysInCourse2, int daysInCourse3);

	~NetworkStudent();

	void print() override;

	Degree getDegreeProgram() override;
};

#endif //CLASSROSTER_NETWORKSTUDENT_H