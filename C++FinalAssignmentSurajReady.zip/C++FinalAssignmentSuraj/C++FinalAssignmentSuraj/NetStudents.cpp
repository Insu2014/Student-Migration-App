#include "stdafx.h"
#include "Netstudents.h"

NetworkStudent::NetworkStudent(std::string studentID, std::string firstName, std::string lastName,
	std::string email,
	int age, int daysInCourse1, int daysInCourse2, int daysInCourse3)
	: Student(studentID, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3) {
	this->degree = degree;
}

NetworkStudent::~NetworkStudent() {
	std::cout << "NetworkStudent destructed" << std::endl;
}

void NetworkStudent::print() {
	std::cout << "ID: " << this->getStudentID() << "\t"
		<< "First Name: " << this->getFirstName() << "\t"
		<< "Last Name: " << this->getLastName() << "\t"
		<< "Age: " << this->getAge() << "\t"
		<< "daysInCourse: {";

	for (int j = 0; j < 3; j++) {
		std::cout << this->getDaysInCourse()[j];
		if (j != 2) {
			std::cout << ", ";
		}
	}

	std::cout << "}\t" << "Degree Program: Networking" << "\t";
	std::cout << std::endl;
}

Degree NetworkStudent::getDegreeProgram() {
	return this->degree;
}