#include "stdafx.h"
#include "SoftStudent.h"

SoftwareStudent::SoftwareStudent(std::string studentID, std::string firstName, std::string lastName,
	std::string email,
	int age, int daysInCourse1, int daysInCourse2, int daysInCourse3)
	: Student(studentID, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3) {
	this->degree = degree;
}

SoftwareStudent::~SoftwareStudent() {
	std::cout << "SoftwareStudent destructed" << std::endl;
}

void SoftwareStudent::print() {
	std::cout << "ID: " << this->getStudentID() << "\t"
		<< "First Name: " << this->getFirstName() << "\t"
		<< "Last Name: " << this->getLastName() << "\t"
		<< "Age: " << this->getAge() << "\t"
		<< "daysInCourse: {";

	for (int j = 0; j < 3; j++) {
		std::cout << this->getDaysInCourse()[j];
		if (j != 2) {
			std::cout << ", ";
		}
	}

	std::cout << "}\t" << "Degree Program: Software" << "\t";
	std::cout << std::endl;
}

Degree SoftwareStudent::getDegreeProgram() {
	return this->degree;
}